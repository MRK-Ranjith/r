package com.cg.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.Entity.Account;
import com.cg.Util.JDBC;


public class AccountDAOImpl implements AccountDAO {
	
	@Override
	public int addcustomer(Integer b,Account a) throws SQLException, ClassNotFoundException {
		Connection c=JDBC.connect();
		Statement stmt=c.createStatement();
		PreparedStatement pst=c.prepareStatement("INSERT INTO ACCOUNT VALUES(?,?,?,?,?)");
		pst.setInt(1,b);
		pst.setString(2, a.getCustomerName());
		pst.setString(3, a.getBranch());
		pst.setString(4, a.getMobno());
		pst.setDouble(5, a.getBalance());
		pst.executeUpdate();
		return 0;
	}
	@Override
	public Account showbalance(int acc) throws ClassNotFoundException, SQLException {
		Connection c=JDBC.connect();
		Statement stmt=c.createStatement();
		ResultSet res=stmt.executeQuery("SELECT * FROM ACCOUNT WHERE ACCOUNTNO=' "+acc+" ' ");
		//System.out.println(res);
		while(res.next())
		{
			int accno=res.getInt(1);
			String name=res.getString(2);
			String branch=res.getString(3);
		    String mob=res.getString(4);
			double bal =res.getDouble(5);
			Account a=new Account(name, branch, mob, bal);
			return a;		
	}
		c.commit();
		return null;
}
	@Override
	public void deposit(double amt,int acc) throws ClassNotFoundException, SQLException {
		Connection c=JDBC.connect();
		Statement stmt=c.createStatement();
			ResultSet res1 =stmt.executeQuery("update ACCOUNT set balance='"+amt+"'where ACCOUNTNO='"+acc+"'"); 
			 
		/*while(res1.next())
		{
			double bal =res1.getDouble(5);
			System.out.println(bal);
			//res1.updateDouble(5, amt);
			res1.updateRow();
			
	}*/
		c.commit();
		
	}
	@Override
	public void withdraw(double res, int acc) throws ClassNotFoundException, SQLException {
		Connection c=JDBC.connect();
		Statement stmt=c.createStatement();
		ResultSet res1 =stmt.executeQuery("update ACCOUNT set balance='"+res+"'where ACCOUNTNO='"+acc+"'"); 	 
				c.commit();
		
	}
		
	
	}
