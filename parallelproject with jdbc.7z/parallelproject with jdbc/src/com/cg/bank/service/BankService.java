package com.cg.bank.service;



import java.sql.SQLException;

import com.cg.bank.entity.Bankcustomer;
import com.cg.bank.excp.BankException;

public interface BankService {
	
	public int createaccount(Integer a,Bankcustomer b) throws ClassNotFoundException, SQLException;
	
	public Bankcustomer getbalance(int a) throws ClassNotFoundException, SQLException;
	
	public Bankcustomer deposit(int accno,double bal) throws SQLException, ClassNotFoundException;
	
	public Bankcustomer withdraw(int accno,double bal) throws ClassNotFoundException, SQLException;
	
	public boolean validateCusName(String name) throws BankException;
		
		
		
		public boolean validateMobileNo(String cellno) throws BankException;
	

}
