package com.parallelproject.bean;

public class Transactions {
private int transactionId;
private int accountno;
private String typeTransaction;
private double transferAmount;
private double balance;
public Transactions() {
	super();
	// TODO Auto-generated constructor stub
}
public Transactions(int transactionId, int accountno, String typeTransaction,
		int transferAmount, int balance) {
	super();
	this.transactionId = transactionId;
	this.accountno = accountno;
	this.typeTransaction = typeTransaction;
	this.transferAmount = transferAmount;
	this.balance = balance;
}
public int getAccountno() {
	return accountno;
}
public double getBalance() {
	return balance;
}
public int getTransactionId() {
	return transactionId;
}
public double getTransferAmount() {
	return transferAmount;
}
public String getTypeTransaction() {
	return typeTransaction;
}
public void setAccountno(int accountno) {
	this.accountno = accountno;
}
public void setBalance(double balance) {
	this.balance = balance;
}
public void setTransactionId(int transactionId) {
	this.transactionId = transactionId;
}
public void setTransferAmount(double transferAmount) {
	this.transferAmount = transferAmount;
}
public void setTypeTransaction(String typeTransaction) {
	this.typeTransaction = typeTransaction;
}
@Override
public String toString() {
	return "Transactions [transactionId=" + transactionId + ", accountno="
			+ accountno + ", typeTransaction=" + typeTransaction
			+ ", transferAmount=" + transferAmount + ", balance=" + balance
			+ "]";
}

}
