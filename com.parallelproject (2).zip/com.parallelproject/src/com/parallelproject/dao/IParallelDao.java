package com.parallelproject.dao;

import java.util.Collection;

import com.parallelproject.bean.Account;
import com.parallelproject.bean.Transactions;
import com.parallelproject.exception.UserException;

public interface IParallelDao {

public int createAccount(Account account,Transactions transaction)throws UserException;
public Account showBalance(int accNO)throws UserException;
public Account deposit(int accNO,double bal,Transactions transaction)throws UserException;
public Account withdraw(int accNO, double amount,Transactions transaction) throws UserException;
public Account fundTransfer(int accNO, int accNO1, double amount,Transactions transaction)throws UserException;
public Collection<Transactions> printTransaction(int accNO,Transactions transaction)throws UserException;

}
