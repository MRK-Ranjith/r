package com.parallelproject.bean;

public class Account {
private  String name;
private  String mobNum;
private  String email;
private  String panNO;
private  String accType;
private String aadharNO;
private static String branch="MRK";
private static String ifsc="MRK0007";
private int accNO;
private double balance;

//public Object setaccNO;

public Account(String name, String mobNum, String email, String panNO, String accType, String aadharNO, double balance  ) {
	super();
	this.name = name;
	this.mobNum = mobNum;
	this.email = email;
	this.panNO = panNO;
	this.accType = accType;
	this.aadharNO = aadharNO;
	this.balance=balance;
	
}

public int getaccNO() {
	return accNO;
}

public void setaccNO(int accNO) {
	this.accNO = accNO;
}

public double getbalance() {
	return balance;
}

public void setbalance(double balance) {
	this.balance = balance;
}




}
