package com.parallelproject.ui;

import java.util.Collection;
import java.util.HashMap;
import java.util.Scanner;



import com.parallelproject.bean.Account;
import com.parallelproject.bean.Transactions;
import com.parallelproject.exception.UserException;
import com.parallelproject.service.IParallelService;
import com.parallelproject.service.ParallelServiceImpl;

public class BankClient {
	
	  static int accNO,opt;static double balance;
	  static IParallelService iserv=null;
      static Scanner scan=new Scanner(System.in);
  
	public static void main(String[] args) throws UserException {
    	Transactions transaction=new Transactions();
    	  HashMap<Integer,Transactions>t=new HashMap<Integer,Transactions>();
    	  

		do {
     System.out.println("Enter the Value");
     System.out.println("1.Create Account \n2.Show Balance \n3.Deposit \n4.Withdraw \n5.Fund Transfer \n6.Print Transaction \n7.Exit");
    switch(opt=scan.nextInt()) {
    case 1:
    	int finalaccNO=createAccount();
    	System.out.println("Account is Generated  ");
    	System.out.println("your Account NO is "+finalaccNO);
    	break;
    	
    case 2:
    	System.out.println("Enter the Account Number");
    	accNO=scan.nextInt();
    	Account b=iserv.showBalance(accNO);
    	System.out.println("Balance is "+b.getbalance());
    	break;
    	
    case 3:
    	System.out.println("Enter the Account Number");
    	accNO=scan.nextInt();
		System.out.println("Amount which you wanted to add");
		double bal=scan.nextDouble();

    	Account b1=iserv.deposit(accNO, bal, transaction);
    	
    	System.out.println("Your Available Balance is "+b1.getbalance());
    	break;
    	
    case 4:
    	System.out.println("Enter the Account Number");
	    accNO=scan.nextInt();
		System.out.println("Amount which you want to withdraw");
		double amount=scan.nextDouble();
	    Account b2=iserv.withdraw(accNO,amount, transaction);
	    
	     System.out.println("Your Available Balance is "+b2.getbalance());
    	break;
    	
    case 5:
    	System.out.println("Enter the Account Number");
	    accNO=scan.nextInt();
		System.out.println("Enter the Account NO to which you what to Transfer fund");
		int accNO1=scan.nextInt();
		System.out.println("Enter the Amount you what to transfer");
		double amount1=scan.nextDouble();

	    Account b3= iserv.fundTransfer(accNO,accNO1,amount1, transaction);
	     
	     System.out.println("Your Available Balance is "+b3.getbalance());
	     break;
	     
    case 6:
    	System.out.println("Enter the Account NO ");
    	accNO=scan.nextInt();
    	Collection<Transactions> b4=iserv.printTransaction(accNO, transaction);
    	for(Transactions trans:b4){
    	System.out.println(b4);}
    	break;
    	
    default:
    	break;
    }
	}while(opt<7);}
	private static int createAccount() throws UserException {
		iserv=new ParallelServiceImpl();
		String name,mobNum,email,panNO,accType;
		String aadharNO;double balance=0;
		do {
		
		System.out.println("Enter the name");
		name=scan.next();}while(iserv.validateName(name)==false);
		do {
		System.out.println("Enter Mobile Number");
		mobNum=scan.next();}while(iserv.validateMobNum(mobNum)==false);
		do {
		System.out.println("Enter email");
		email=scan.next();}while(iserv.validateEmail(email)==false);
		do {
		System.out.println("Enter panNO");
		panNO=scan.next();}while(iserv.validatePanNO(panNO)==false);
		do {
		System.out.println("Enter account Type");
		accType=scan.next();}while(iserv.validateAccType(accType)==false);
		do {
		System.out.println("Enter aadhar Number");
		aadharNO=scan.next();}while(iserv.validateAadharNO(aadharNO)==false);
		do {
			System.out.println("Enter the Balance");
			balance=scan.nextDouble();}while(iserv.validateBalance(balance)==false);
		
		
		Account account=new Account(name,mobNum,email,panNO,accType,aadharNO,balance);
		Transactions transaction = new Transactions();     
		
		return  iserv.createAccount(account,transaction);
	}
  
}
