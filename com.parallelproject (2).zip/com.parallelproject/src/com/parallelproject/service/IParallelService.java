package com.parallelproject.service;

import java.util.Collection;

import com.parallelproject.bean.Account;
import com.parallelproject.bean.Transactions;
import com.parallelproject.exception.UserException;

public interface IParallelService {
public int createAccount(Account account,Transactions transaction) throws UserException;
public Account showBalance(int accNO) throws UserException;
public Account deposit(int accNO, double bal,Transactions transaction) throws UserException;
public Account withdraw(int accNO, double amount, Transactions transaction) throws UserException;

public Account fundTransfer(int accNO, int accNO1, double amount1, Transactions transaction ) throws UserException;
public Collection<Transactions> printTransaction(int accNO, Transactions transaction)
 throws UserException;
public boolean validateName(String name);
public boolean validateMobNum(String mobNum);
public boolean validateEmail(String email);
public boolean validatePanNO(String panNO);
public boolean validateAccType(String accType);
public boolean validateAadharNO(String aadharNO);
public boolean validateBalance(double balance);

}