package com.parallelproject.dao;

import java.util.Collection;
import java.util.HashMap;
import java.util.Scanner;

import com.parallelproject.bean.Account;
import com.parallelproject.bean.Transactions;
import com.parallelproject.exception.UserException;

public class ParallelDaoImpl implements IParallelDao {
	Scanner scan=new Scanner(System.in);
	static double balance;
	
 static HashMap<Integer,Account>m=new HashMap<Integer,Account>();
 static HashMap<Integer,Transactions>t=new HashMap<Integer,Transactions>();

	@Override
	public int createAccount(Account account,Transactions transaction)  throws UserException{
		m.put(account.getaccNO(), account);
		transaction.setAccountno(account.getaccNO());
		transaction.setTransferAmount(account.getbalance());
		transaction.setBalance(account.getbalance());
		transaction.setTypeTransaction("CreateAccount");
		t.put(transaction.getTransactionId(), transaction);
          return account.getaccNO();		
	}

	@Override
	public Account showBalance(int accNO)  throws UserException{
		//Account a=m.get(accNO);
		Collection<Account>l=m.values();
		for(Account d:l) {
			if(d.getaccNO()==accNO) {
				
			}
				
//			else{
//				System.out.println("Invalid Account Number");
//			}
		}
		Account a=m.get(accNO);
		return a;

	}

	@Override
	public Account deposit(int accNO,double bal,Transactions transaction)  throws UserException{
				
		Collection<Account>l=m.values();
		double balance=0;
		for(Account d:l) {
			if(d.getaccNO()==accNO) {
				 balance=d.getbalance()+bal;
				d.setbalance(balance);
			}			
		}
		Account a=m.get(accNO);
		transaction.setAccountno(accNO);
		transaction.setTransferAmount(bal);
		transaction.setBalance(balance);
		transaction.setTypeTransaction("Deposit");
		t.put(transaction.getTransactionId(), transaction);
		return a;
	}

	@Override
	public Account withdraw(int accNO,double amount,Transactions transaction)  throws UserException{
		
		Collection<Account>l=m.values();
		double balance=0;
		for(Account d:l) {
			if(d.getaccNO()==accNO) {
				balance=d.getbalance()-amount;
				d.setbalance(balance); 
			}}
		Account a=m.get(accNO);
		transaction.setAccountno(accNO);
		transaction.setTransferAmount(amount);
		transaction.setBalance(balance);
		transaction.setTypeTransaction("withDraw");
		t.put(transaction.getTransactionId(), transaction);
		return a;
	}

	@Override
	public Account fundTransfer(int accNO,int accNO1,double amount,Transactions transaction)  throws UserException{
		
		Collection<Account>l=m.values();
		double balance=0;
		for(Account a:l) {
		if(a.getaccNO()==accNO){

			if(a.getbalance()>=amount) {
				balance=a.getbalance()-amount;
				a.setbalance(balance);
				}else {
					System.out.println("Your balance is less to transfer the amount YOU what to send");
					
				}}	}
			for(Account b:l) {

		   if(b.getaccNO()==accNO1){

				balance=b.getbalance()+amount;
				b.setbalance(balance);
				}}
	
		
		
	
		Account a=m.get(accNO);
		transaction.setAccountno(accNO);
		transaction.setTransferAmount(amount);
		transaction.setBalance(balance);
		transaction.setTypeTransaction("withDraw");
		t.put(transaction.getTransactionId(), transaction);
		return a; }

	@Override
	public Collection<Transactions> printTransaction(int accNO,Transactions transaction)  throws UserException{
		Collection<Transactions>k=t.values();
		return k;
		
		
	}

	}



