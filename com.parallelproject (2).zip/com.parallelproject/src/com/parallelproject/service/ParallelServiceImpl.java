package com.parallelproject.service;

import java.util.Collection;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.parallelproject.bean.Account;
import com.parallelproject.bean.Transactions;
import com.parallelproject.dao.IParallelDao;
import com.parallelproject.dao.ParallelDaoImpl;
import com.parallelproject.exception.UserException;
import com.parallelproject.exception.UserException;
 
public class ParallelServiceImpl implements IParallelService{
	IParallelDao idao=null;
	
    public static int generateAccNO() {
    	return (int)(Math.random()*10000000);
    }
    public static int generateTransactionId() {
    	return (int)(Math.random()*10000);
    }
    
    
	@Override
	public int createAccount(Account account,Transactions transaction)throws UserException {
		account.setaccNO(generateAccNO());
		transaction.setTransactionId(generateTransactionId());
		idao=new ParallelDaoImpl();
    return idao.createAccount(account,transaction);		
	}

	@Override
	public Account showBalance(int accNO)throws UserException {		
	return	 idao.showBalance(accNO);

	}

	@Override
	public Account deposit(int accNO,double bal,Transactions transaction) throws UserException{
		transaction.setTransactionId(generateTransactionId());
		return idao.deposit(accNO,bal,transaction);
	}

	@Override
	public Account withdraw(int accNO, double amount, 	Transactions transaction)throws UserException {
		transaction.setTransactionId(generateTransactionId());

		return idao.withdraw(accNO, amount,transaction);
	}

	@Override
	public Account fundTransfer(int accNO,int accNO1,double amount,Transactions transaction)throws UserException {
		
		transaction.setTransactionId(generateTransactionId());
         return idao.fundTransfer(accNO,accNO1,amount,transaction);
	}

	@Override
	public Collection<Transactions>  printTransaction(int accNO,Transactions transaction)throws UserException {
		return idao.printTransaction(accNO,transaction);

	}
	@Override
	public boolean validateName(String name) {
		Pattern p=Pattern.compile("^[A-Z]{1}[a-z]{3,}");
		Matcher m=p.matcher(name);
		if(m.find()) {
			return true;
		}else 	return false;
	
	}

	@Override
	public boolean validateMobNum(String mobNum) {
		Pattern p=Pattern.compile("^[6-9]{1}[0-9]{9}$");
		Matcher m=p.matcher(mobNum);
		if(m.find()) {
			return true;}
		return false;
	}

	@Override
	public boolean validateEmail(String email) {
		Pattern p=Pattern.compile("^([a-z]{5,}[0-9]{0,})(@[a-z]{3,}.com)$");
		Matcher m=p.matcher(email);
		if(m.find()) {
			return true;}		
		return false;
	}

	@Override
	public boolean validatePanNO(String panNO) {
		Pattern p=Pattern.compile("^[A-Z]{5}[0-9]{4}[A-Z]{1}$");
		Matcher m=p.matcher(panNO);
		if(m.find()) {
			return true;}		
		return false;
	}

	@Override
	public boolean validateAccType(String accType) {
		if((accType.equalsIgnoreCase("savings")) || (accType.equalsIgnoreCase("current") )){
			return true;
		}
		return false;
	}

	@Override
	public boolean validateAadharNO(String aadharNO) {
		Pattern p=Pattern.compile("^[5-9]{1}[0-9]{11}$");
		Matcher m=p.matcher(aadharNO);
		if(m.find()) {
			return true;}
		return false;
		}
	@Override
	public boolean validateBalance(double balance) {
		if(balance>500) {
			return true;	
		}
		return false;
	}
	}


