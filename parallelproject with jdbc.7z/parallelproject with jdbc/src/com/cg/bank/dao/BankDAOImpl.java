package com.cg.bank.dao;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.bank.entity.Bankcustomer;
import com.cg.bank.util.ConnectionSql;

public class BankDAOImpl implements BankDAO{

	@Override
	public void createaccount(Integer a, Bankcustomer b) throws ClassNotFoundException, SQLException {
		
		Connection con=ConnectionSql.connect();
		Statement stmt =con.createStatement();
		PreparedStatement pst =con.prepareStatement("INSERT INTO BankCustomer VALUES(?,?,?,?,?)");
		pst.setInt(1, a);
		pst.setString(2, b.getCustomername());
		pst.setString(3, b.getMobileno());
		pst.setString(4, b.getbranch());
		pst.setDouble(5, b.getBalance());
		pst.executeUpdate();
	}

	@Override
	public Bankcustomer getbalance(int accno) throws ClassNotFoundException, SQLException {
		Connection con=ConnectionSql.connect();
		Statement stmt =con.createStatement();
		ResultSet res =stmt.executeQuery("select * from BankCustomer where accountnumber='"+accno+" ' ");
		while(res.next()){
			int accountnumber=res.getInt(1);
			String customername=res.getString(2);
			String mobilenumber=res.getString(3);
			String branch=res.getString(4);
			double balance=res.getDouble(5);
			Bankcustomer bc=new Bankcustomer(customername, mobilenumber, branch, balance);
		return  bc;
	}
		return null;
	}

	@Override
	public Bankcustomer deposit(int accno ,double bal) throws ClassNotFoundException, SQLException{
		Connection con=ConnectionSql.connect();
		Statement stmt =con.createStatement();
		ResultSet res =stmt.executeQuery("update BankCustomer set balance='"+bal+"'where accountnumber='"+accno+"'");
		
		return null;
	}
	

	@Override
	public Bankcustomer withdraw(int accno,double bal) throws ClassNotFoundException, SQLException {
		Connection con=ConnectionSql.connect();
		Statement stmt =con.createStatement();
		ResultSet res =stmt.executeQuery("update BankCustomer set balance='"+bal+"'where accountnumber='"+accno+"'");
		
		return null;
	}

	
	

	
}
