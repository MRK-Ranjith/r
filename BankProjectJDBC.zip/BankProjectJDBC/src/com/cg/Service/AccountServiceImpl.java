package com.cg.Service;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.cg.DAO.AccountDAO;
import com.cg.DAO.AccountDAOImpl;
import com.cg.Entity.Account;

public class AccountServiceImpl implements AccountService {

	AccountDAO ad=new AccountDAOImpl();
	@Override
	public int addcustomer(Integer b,Account a) throws SQLException, ClassNotFoundException {
		ad.addcustomer(b,a);
		return 0;
	}
	@Override
	public Account showbalance(int acc) throws ClassNotFoundException, SQLException {
		Account a=ad.showbalance(acc);
		return a;
	}

	@Override
	public boolean validateCustomerName(String name) {
		Pattern p=Pattern.compile("[A-Z]{1}[a-z]{1,14}");
		Matcher ename=p.matcher(name);
			if(ename.matches())
		{
			return true;
		}
		return false;	
	}	
	@Override
	public boolean ValidateCustomerMobileno(String cid) {
		Pattern p=Pattern.compile("[9]{1}[0-9]{9}");
		Matcher m=p.matcher(cid);
		if(m.matches())
		{
			return true;
		}	
			return false;
	}

	@Override
	public boolean ValidateBranch(String name) {
		Pattern p=Pattern.compile("[A-Z]{1}[a-z]{1,14}");
		Matcher name1=p.matcher(name);
			if(name1.matches())
		{
			return true;
		}
		return false;
}
	@Override
	public void deposit(double amt,int acc) throws ClassNotFoundException, SQLException {
		 ad.deposit(amt,acc);
		
	}
	@Override
	public void withdraw(double res, int acc) throws ClassNotFoundException, SQLException {
		 ad.deposit(res,acc);
		
	}
}